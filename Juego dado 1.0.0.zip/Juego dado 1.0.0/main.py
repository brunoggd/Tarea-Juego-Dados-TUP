from personaje import *
from dado import *
from funciones import *
from recursos import *
from tablero_y_casillas import *
from bot import *

def main():
    mostrar_portada(portada)

    ingresar_participantes()
    determinar_orden()

if __name__ == "__main__":
    main()


